﻿public static class StartupEvent {
	public const string MANAGERS_STARTED = "MANAGERS_STARTED";
	public const string MANAGERS_PROGRESS = "MANAGERS_PROGRESS";
}