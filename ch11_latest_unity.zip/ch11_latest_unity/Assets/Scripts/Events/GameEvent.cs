﻿public static class GameEvent {
	public const string HEALTH_UPDATED = "HEALTH_UPDATED";
	public const string LEVEL_FAILED = "LEVEL_FAILED";
	public const string LEVEL_COMPLETE = "LEVEL_COMPLETE";
	public const string GAME_COMPLETE = "GAME_COMPLETE";
}