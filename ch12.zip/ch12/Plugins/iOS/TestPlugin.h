#import <Foundation/Foundation.h>

@interface TestObject : NSObject {
	NSString* status;
}

@end